SET NOCOUNT ON;

SELECT l0.row_id, l0.url, l0.raw_url_id, l0.flags, l1.row_id, l1.url, l1.flags, l1.uid, l2.row_id, l2.url, l2.flags, l3.row_id, l3.url, l3.flags FROM RtmUrl l0 LEFT JOIN RtmUrlMapping0to1 m0 ON m0.child_id = l0.row_id LEFT JOIN RtmUrlLabelLevel1 l1 ON m0.parent_id = l1.row_id LEFT JOIN RtmUrlMapping1to2 m1 ON m1.child_id = l1.row_id LEFT JOIN RtmUrlLabelLevel2 l2 ON m1.parent_id = l2.row_id LEFT JOIN RtmUrlMapping2to3 m2 ON m2.child_id = l2.row_id LEFT JOIN RtmUrlLabelLevel3 l3 ON m2.parent_id = l3.row_id WHERE l0.row_id = 1;

-- missing urls from rtmserver
select * from RtmServer where url_id not in (select row_id from RtmUrl);
 
-- missing raw_urls
select * from RtmUrl where raw_url_id <> -1 and raw_url_id not in (select row_id from RtmRawUrl);
 
-- dummy raw_urls
--select * from RtmRawUrl where row_id not in (select raw_url_id from RtmUrl);
 
-- level 0
select * from RtmUrlMapping0to1 where child_id not in ( select row_id from rtmurl)
select * from RtmUrlMapping0to1 where parent_id not in ( select row_id from RtmUrlLabelLevel1)
select * from rtmurl where row_id not in (select child_id from RtmUrlMapping0to1);
 
-- level 1
select * from RtmUrlLabelLevel1 where row_id not in (select child_id from RtmUrlMapping1to2);
select * from RtmUrlMapping1to2 where parent_id not in ( select row_id from RtmUrlLabelLevel2)
select * from RtmUrlLabelLevel1 where row_id not in (select child_id from RtmUrlMapping1to2);

-- level 2
select * from RtmUrlLabelLevel2 where row_id not in (select child_id from RtmUrlMapping2to3);
select * from RtmUrlMapping2to3 where parent_id not in ( select row_id from RtmUrlLabelLevel3);

-- duplicated urls
SELECT *
FROM
	rtmurl
WHERE
	url IN (SELECT url
			FROM
				RtmUrl
			GROUP BY
				url
			HAVING
				count(*) > 1) AND
	row_id NOT IN (SELECT min(row_id) AS min_row_id
				   FROM
					   RtmUrl
				   WHERE
					   url IN (SELECT url
							   FROM
								   RtmUrl
							   GROUP BY
								   url
							   HAVING
								   count(*) > 1)
				   GROUP BY
					   url) AND
	row_id NOT IN (SELECT url_id
				   FROM
					   rtmbussgroupdef bgconf, rtmbussgroup bg
				   WHERE
					   row_id = bg_id
					   AND
					   bg.url_id <> -1
					   AND
					   bgconf.flags & 0x1f < 2
				   GROUP BY
					   url_id);

-- duplicated servers
SELECT addr_svr
	 , url_id
	 , count(*) AS CNT
FROM
	RtmServer
GROUP BY
	addr_svr
  , url_id
HAVING
	count(*) > 1;

-- hierarchy check	
SELECT *
FROM
	RtmUrl
WHERE
	row_id NOT IN (SELECT l0.row_id
				   FROM
					   RtmUrl l0
					   LEFT JOIN RtmUrlMapping0to1 m0
						   ON m0.child_id = l0.row_id
					   LEFT JOIN RtmUrlLabelLevel1 l1
						   ON m0.parent_id = l1.row_id
					   LEFT JOIN RtmUrlMapping1to2 m1
						   ON m1.child_id = l1.row_id
					   LEFT JOIN RtmUrlLabelLevel2 l2
						   ON m1.parent_id = l2.row_id
					   LEFT JOIN RtmUrlMapping2to3 m2
						   ON m2.child_id = l2.row_id
					   LEFT JOIN RtmUrlLabelLevel3 l3
						   ON m2.parent_id = l3.row_id);
