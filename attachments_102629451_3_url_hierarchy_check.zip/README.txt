Description:
This script checks the consistency of the URL hierarchy in the CAS database. It is suggested to execute this prior to an upgrade in order to validate the consistency of the URL hierarchy structure. Please visit the APM Community Migration Center for the latest updates on this script.

Supported versions:
This script should work on any version from (including) 11.6.0 to 12.1.1.

Usage instructions: 
1. Open the "url_hierarchy_check.sql script in any text editor and copy its contents
2. Go to http://<CAS ip>/sqlreports
3. Paste the text into the text area
4. Click the "Execute" button

The script should be executed from http://<CAS ip>/sqlreports. If for some reason you cannot execute it there, you may execute it from within SQL Management Studio, but you would have to adjust the script and prefix all the tables with the schema name (i.e. delta.rtmurl or dbo.rtmurl instead of just rtmurl).

Results:
The script should return 1 row for the first query - It should point only to "empty" urls (All other). All other queries should not return any records. If they do, then there's some inconsistency in the hierarchy. Please contact support and report the issue if this occurs.
